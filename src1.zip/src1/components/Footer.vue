<template>
   <footer class="footer">
      <p class="footer__description">
         Mrs.Boden&Mrs.Hyuk
      </p>
      <p class="footer__description">
         &copy; Copyright All rights reserved.
      </p>
   </footer>   
</template>

<script>
export default {
   name: 'Footer'
}
</script>

<style lang="postcss" scoped>
@import "../styles/base/_variables.css";
@import "../styles/base/_global.css";
@import "../styles/modules/_footer.css";
</style>
