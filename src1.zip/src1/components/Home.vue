<template>
    <div>
        <div class="image">
            <img class="bg1" src="../assets/bg.png">
            <img class="bg2" src="../assets/bg2.png">
        </div>    
        <div class="text">
            <p class="head">推薦商品</p>
            
            <p class="subhead">以下為熱門推薦商品</p>
        </div>    
    </div>
</template>

<style lang="postcss" scoped>
@import "../styles/base/_variables.css";
@import "../styles/base/_global.css";
@import "../styles/modules/_home.css";
</style>