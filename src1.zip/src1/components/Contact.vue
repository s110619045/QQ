<template>
    <div  class="contact">
        <img class="contact_img" src="../assets/contact.jpg">
        <div class="contact_text">
            <p class="pt">Name</p>
            <p class="pi">黃翔莉(左) 李欣霏(右）</p>
            <p class="pt">EMAIL</p>
            <p class="pi">s110619045@stu.ntue.edu.tw</p>
            <p class="pi">s110619046@stu.ntue.edu.tw</p>
        </div>

    </div>
</template>

<script>
export default {
   name: 'Contact'
}
</script>

<style lang="postcss" scoped>
@import "../styles/base/_variables.css";
@import "../styles/base/_global.css";
@import "../styles/modules/_contact.css";
</style>